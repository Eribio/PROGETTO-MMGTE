/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author those
 */
public class Sensore {
        private int id;
	private String tipo;
	private float p;
	private float t1;
	private float t2;
	
	public Sensore(int id, String tipo, float p, float t1, float t2) {
		this.id = id;
		this.tipo = tipo;
		this.p = p;
		this.t1 = t1;
		this.t2 = t2;
	}
	public int rest_id() {
		return this.id;
	}
        public float cambio_valore(float f) {
		return this.p=f;
	}
	public float get() {
		return this.p;
	}
	public String rest_tipo() {
		return this.tipo;
	}
	public boolean invio () {
		ArrayList<Object> lista= new ArrayList<>();
		lista.add(p);
		lista.add(id);
		boolean inserimento= new Connessione().insert(lista);
		return inserimento;
	}
    
}
