/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
/**
 *
 * @author those
 */
public class Server {
    

	public Server() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
    	 int cont=0;
			try {
				ServerSocket ss = new ServerSocket(9888) ;
				while (true) {
					Socket s = ss.accept() ;
					for (int i=0;i<48;i++) {
					System.out.println(s.getInputStream().read()); 
					cont++;}
					System.out.println(cont);
					s.close();
					ss.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			  }
      }}
