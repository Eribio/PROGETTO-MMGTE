/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author those
 */
public class Controller {
    Connection con2= null;
    PreparedStatement pst = null;
    PreparedStatement pst1 = null;
    PreparedStatement pst2 = null;
    ResultSet rs = null;
    ResultSet rs1 = null;
    ResultSet rs2 = null;
    Random random=new Random();
    int id2=0;
    public Controller(Sensore s){
        this.id2=s.rest_id();
        
    }
    public int controllo(){
        int casuale=0;
        String sql= "select ID from sensore where tipo='temperatura'";
        String sql1= "select ID from sensore where tipo='umidita'";
        String sql2= "select ID from sensore where tipo='pressione'";
       try {
           con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/ospedale","root","ciao123abcd");
       } catch (SQLException ex) {
           Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
       }
        try{
            pst= con2.prepareStatement(sql);
            pst1= con2.prepareStatement(sql1);
            pst2= con2.prepareStatement(sql2);
            pst.execute();
            pst1.execute();
            pst2.execute();
            rs=pst.getResultSet();
            rs1=pst1.getResultSet();
            rs2=pst2.getResultSet();
            while(rs.next())
                if (rs.getInt("ID")==id2){
                    System.out.println("ID numero " + rs.getInt("ID") + " è di tipo temperatura");
                    casuale= random.nextInt((30-15)+1)+15;
                    System.out.println(casuale);
                }
            while(rs1.next())
                if (rs1.getInt("ID")==id2){
                    System.out.println("ID numero " + rs1.getInt("ID") + " è di tipo umidita");
                    casuale= random.nextInt((70-30)+1)+30;
                    System.out.println(casuale);
                }
            while(rs2.next())
                if (rs2.getInt("ID")==id2){
                    System.out.println("ID numero " + rs2.getInt("ID") + " è di tipo pressione");
                    casuale= random.nextInt((31-5)+1)+5;
                    System.out.println(casuale);
                }
            
                    
               
    }catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex);
        } 
        return casuale;
}}
    
