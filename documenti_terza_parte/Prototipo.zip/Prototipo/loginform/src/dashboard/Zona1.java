
package dashboard;
import java.awt.Color;
import javax.swing.Timer;
import java.awt.Event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;


public class Zona1 extends JFrame implements ActionListener {
    
    Timer t=new Timer(10000,this);
    Connection con1= null;
    PreparedStatement pst5 = null;
    PreparedStatement pst6 = null;
    PreparedStatement pst7 = null;
    PreparedStatement pst8 = null;
    PreparedStatement pst9 = null;
    PreparedStatement pst10 = null;
    PreparedStatement pst11 = null;
    PreparedStatement pst12 = null;
    PreparedStatement pst13 = null;
    PreparedStatement pst14 = null;
    PreparedStatement pst15 = null;
    PreparedStatement pst16 = null;
    PreparedStatement pst17 = null;
    PreparedStatement pst18 = null;
    PreparedStatement pst19 = null;
    PreparedStatement pst20 = null;
    PreparedStatement pst21 = null;
    PreparedStatement pst22 = null;
    PreparedStatement pst23 = null;
    PreparedStatement pst24 = null;
    PreparedStatement pst25 = null;
    PreparedStatement pst26 = null;
    PreparedStatement pst27 = null;
    PreparedStatement pst28 = null;
    PreparedStatement pst29 = null;
    PreparedStatement pst30 = null;
    PreparedStatement pst31 = null;
    PreparedStatement pst32 = null;
    PreparedStatement pst33 = null;
    PreparedStatement pst34 = null;
    PreparedStatement pst35 = null;
    PreparedStatement pst36 = null;
    PreparedStatement pst37 = null;
    PreparedStatement pst38 = null;
    PreparedStatement pst39 = null;
    PreparedStatement pst40 = null;
    PreparedStatement pst41 = null;
    PreparedStatement pst42 = null;
    PreparedStatement pst43 = null;
    PreparedStatement pst44 = null;
    PreparedStatement pst45 = null;
    PreparedStatement pst46 = null;
    PreparedStatement pst47 = null;
    PreparedStatement pst48 = null;
    PreparedStatement pst49 = null;
    PreparedStatement pst50 = null;
    PreparedStatement pst51 = null;
    PreparedStatement pst52 = null;
    ResultSet rs5 = null;
    ResultSet rs6 = null;
    ResultSet rs7 = null;
    ResultSet rs8 = null;
    ResultSet rs9 = null;
    ResultSet rs10 = null;
    ResultSet rs11 = null;
    ResultSet rs12 = null;
    ResultSet rs13 = null;
    ResultSet rs14 = null;
    ResultSet rs15 = null;
    ResultSet rs16 = null;
    ResultSet rs17 = null;
    ResultSet rs18 = null;
    ResultSet rs19 = null;
    ResultSet rs20 = null;
    ResultSet rs21 = null;
    ResultSet rs22 = null;
    ResultSet rs23 = null;
    ResultSet rs24 = null;
    ResultSet rs25 = null;
    ResultSet rs26 = null;
    ResultSet rs27 = null;
    ResultSet rs28 = null;
    ResultSet rs29 = null;
    ResultSet rs30 = null;
    ResultSet rs31 = null;
    ResultSet rs32 = null;
    ResultSet rs33 = null;
    ResultSet rs34 = null;
    ResultSet rs35 = null;
    ResultSet rs36 = null;
    ResultSet rs37 = null;
    ResultSet rs38 = null;
    ResultSet rs39 = null;
    ResultSet rs40 = null;
    ResultSet rs41 = null;
    ResultSet rs42 = null;
    ResultSet rs43 = null;
    ResultSet rs44 = null;
    ResultSet rs45 = null;
    ResultSet rs46 = null;
    ResultSet rs47 = null;
    ResultSet rs48 = null;
    ResultSet rs49 = null;
    ResultSet rs50 = null;
    ResultSet rs51 = null;
    ResultSet rs52 = null;
    
    public Zona1() {
        t.start();
        
        
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        t11 = new javax.swing.JLabel();
        t12 = new javax.swing.JLabel();
        u11 = new javax.swing.JLabel();
        Stanza1 = new javax.swing.JLabel();
        Stanza2 = new javax.swing.JLabel();
        Stanza3 = new javax.swing.JLabel();
        Stanza4 = new javax.swing.JLabel();
        Stanza5 = new javax.swing.JLabel();
        Bagno = new javax.swing.JLabel();
        SalaDiAttesa = new javax.swing.JLabel();
        Corridoio = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        u12 = new javax.swing.JLabel();
        p11 = new javax.swing.JLabel();
        p12 = new javax.swing.JLabel();
        t21 = new javax.swing.JLabel();
        t22 = new javax.swing.JLabel();
        u21 = new javax.swing.JLabel();
        u22 = new javax.swing.JLabel();
        p21 = new javax.swing.JLabel();
        p22 = new javax.swing.JLabel();
        t31 = new javax.swing.JLabel();
        t32 = new javax.swing.JLabel();
        u31 = new javax.swing.JLabel();
        u32 = new javax.swing.JLabel();
        p31 = new javax.swing.JLabel();
        p32 = new javax.swing.JLabel();
        t41 = new javax.swing.JLabel();
        t42 = new javax.swing.JLabel();
        u41 = new javax.swing.JLabel();
        u42 = new javax.swing.JLabel();
        p41 = new javax.swing.JLabel();
        p42 = new javax.swing.JLabel();
        t52 = new javax.swing.JLabel();
        u51 = new javax.swing.JLabel();
        u52 = new javax.swing.JLabel();
        p51 = new javax.swing.JLabel();
        p52 = new javax.swing.JLabel();
        t51 = new javax.swing.JLabel();
        t62 = new javax.swing.JLabel();
        u61 = new javax.swing.JLabel();
        u62 = new javax.swing.JLabel();
        p61 = new javax.swing.JLabel();
        p62 = new javax.swing.JLabel();
        t61 = new javax.swing.JLabel();
        t72 = new javax.swing.JLabel();
        u71 = new javax.swing.JLabel();
        u72 = new javax.swing.JLabel();
        p71 = new javax.swing.JLabel();
        p72 = new javax.swing.JLabel();
        t71 = new javax.swing.JLabel();
        t81 = new javax.swing.JLabel();
        t82 = new javax.swing.JLabel();
        u81 = new javax.swing.JLabel();
        u82 = new javax.swing.JLabel();
        p81 = new javax.swing.JLabel();
        p82 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        jButton1.setText("Aggiornamento in corso...");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        t11.setForeground(new java.awt.Color(0, 153, 51));
        t11.setText("-");

        t12.setForeground(new java.awt.Color(0, 153, 51));
        t12.setText("-");

        u11.setForeground(new java.awt.Color(0, 153, 51));
        u11.setText("-");

        Stanza1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Stanza1.setForeground(new java.awt.Color(0, 153, 51));
        Stanza1.setText("STANZA 1");

        Stanza2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Stanza2.setForeground(new java.awt.Color(0, 153, 51));
        Stanza2.setText("STANZA 2");

        Stanza3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Stanza3.setForeground(new java.awt.Color(0, 153, 51));
        Stanza3.setText("STANZA 3");

        Stanza4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Stanza4.setForeground(new java.awt.Color(0, 153, 51));
        Stanza4.setText("STANZA 4");

        Stanza5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Stanza5.setForeground(new java.awt.Color(0, 153, 51));
        Stanza5.setText("STANZA 5");

        Bagno.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Bagno.setForeground(new java.awt.Color(0, 153, 51));
        Bagno.setText("BAGNO");

        SalaDiAttesa.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        SalaDiAttesa.setForeground(new java.awt.Color(0, 153, 51));
        SalaDiAttesa.setText("SALA DI ATTESA");

        Corridoio.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Corridoio.setForeground(new java.awt.Color(0, 153, 51));
        Corridoio.setText("CORRIDOIO");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("T1");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("T2");

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setText("U1");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setText("U2");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setText("P1");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("P2");

        u12.setForeground(new java.awt.Color(0, 153, 51));
        u12.setText("-");

        p11.setForeground(new java.awt.Color(0, 153, 51));
        p11.setText("-");

        p12.setForeground(new java.awt.Color(0, 153, 51));
        p12.setText("-");

        t21.setForeground(new java.awt.Color(0, 153, 51));
        t21.setText("-");

        t22.setForeground(new java.awt.Color(0, 153, 51));
        t22.setText("-");

        u21.setForeground(new java.awt.Color(0, 153, 51));
        u21.setText("-");

        u22.setForeground(new java.awt.Color(0, 153, 51));
        u22.setText("-");

        p21.setForeground(new java.awt.Color(0, 153, 51));
        p21.setText("-");

        p22.setForeground(new java.awt.Color(0, 153, 51));
        p22.setText("-");

        t31.setForeground(new java.awt.Color(0, 153, 51));
        t31.setText("-");

        t32.setForeground(new java.awt.Color(0, 153, 51));
        t32.setText("-");

        u31.setForeground(new java.awt.Color(0, 153, 51));
        u31.setText("-");

        u32.setForeground(new java.awt.Color(0, 153, 51));
        u32.setText("-");

        p31.setForeground(new java.awt.Color(0, 153, 51));
        p31.setText("-");

        p32.setForeground(new java.awt.Color(0, 153, 51));
        p32.setText("-");

        t41.setForeground(new java.awt.Color(0, 153, 51));
        t41.setText("-");

        t42.setForeground(new java.awt.Color(0, 153, 51));
        t42.setText("-");

        u41.setForeground(new java.awt.Color(0, 153, 51));
        u41.setText("-");

        u42.setForeground(new java.awt.Color(0, 153, 51));
        u42.setText("-");

        p41.setForeground(new java.awt.Color(0, 153, 51));
        p41.setText("-");

        p42.setForeground(new java.awt.Color(0, 153, 51));
        p42.setText("-");

        t52.setForeground(new java.awt.Color(0, 153, 51));
        t52.setText("-");

        u51.setForeground(new java.awt.Color(0, 153, 51));
        u51.setText("-");

        u52.setForeground(new java.awt.Color(0, 153, 51));
        u52.setText("-");

        p51.setForeground(new java.awt.Color(0, 153, 51));
        p51.setText("-");

        p52.setForeground(new java.awt.Color(0, 153, 51));
        p52.setText("-");

        t51.setForeground(new java.awt.Color(0, 153, 51));
        t51.setText("-");

        t62.setForeground(new java.awt.Color(0, 153, 51));
        t62.setText("-");

        u61.setForeground(new java.awt.Color(0, 153, 51));
        u61.setText("-");

        u62.setForeground(new java.awt.Color(0, 153, 51));
        u62.setText("-");

        p61.setForeground(new java.awt.Color(0, 153, 51));
        p61.setText("-");

        p62.setForeground(new java.awt.Color(0, 153, 51));
        p62.setText("-");

        t61.setForeground(new java.awt.Color(0, 153, 51));
        t61.setText("-");

        t72.setForeground(new java.awt.Color(0, 153, 51));
        t72.setText("-");

        u71.setForeground(new java.awt.Color(0, 153, 51));
        u71.setText("-");

        u72.setForeground(new java.awt.Color(0, 153, 51));
        u72.setText("-");

        p71.setForeground(new java.awt.Color(0, 153, 51));
        p71.setText("-");

        p72.setForeground(new java.awt.Color(0, 153, 51));
        p72.setText("-");

        t71.setForeground(new java.awt.Color(0, 153, 51));
        t71.setText("-");

        t81.setForeground(new java.awt.Color(0, 153, 51));
        t81.setText("-");

        t82.setForeground(new java.awt.Color(0, 153, 51));
        t82.setText("-");

        u81.setForeground(new java.awt.Color(0, 153, 51));
        u81.setText("-");

        u82.setForeground(new java.awt.Color(0, 153, 51));
        u82.setText("-");

        p81.setForeground(new java.awt.Color(0, 153, 51));
        p81.setText("-");

        p82.setForeground(new java.awt.Color(0, 153, 51));
        p82.setText("-");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel15.setText("UFFICI");

        jButton2.setText("Indietro");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Stanza2)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Stanza3)
                        .addGap(95, 95, 95)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(t31)
                                    .addComponent(t21))
                                .addGap(111, 111, 111)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(t22)
                                    .addComponent(t32))
                                .addGap(11, 11, 11))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(t11))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(t12)
                                    .addComponent(jLabel10))))
                        .addGap(99, 99, 99)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(u11)
                            .addComponent(jLabel11)
                            .addComponent(u21)
                            .addComponent(u31))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(100, 100, 100)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(u22)
                                    .addComponent(u32)
                                    .addComponent(u42)
                                    .addComponent(u52)
                                    .addComponent(u62))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(u12)
                                    .addComponent(jLabel12))
                                .addGap(283, 283, 283))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Stanza1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p11)
                            .addComponent(jLabel13)
                            .addComponent(p31)
                            .addComponent(p21)
                            .addComponent(p41)
                            .addComponent(p51)
                            .addComponent(p61)
                            .addComponent(p71)
                            .addComponent(p81))
                        .addGap(101, 101, 101)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p32)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(p22)
                                    .addGap(11, 11, 11))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel14)
                                    .addComponent(p12)))
                            .addComponent(p42)
                            .addComponent(p52)
                            .addComponent(p62)
                            .addComponent(p72)
                            .addComponent(p82))
                        .addGap(38, 38, 38))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Stanza4)
                            .addComponent(Stanza5)
                            .addComponent(Bagno)
                            .addComponent(SalaDiAttesa)
                            .addComponent(Corridoio))
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(t81)
                                .addGap(111, 111, 111)
                                .addComponent(t82)
                                .addGap(110, 110, 110)
                                .addComponent(u81))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(t71)
                                .addGap(111, 111, 111)
                                .addComponent(t72)
                                .addGap(110, 110, 110)
                                .addComponent(u71))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(t51)
                                        .addComponent(t41))
                                    .addGap(111, 111, 111)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(t42)
                                            .addGap(110, 110, 110)
                                            .addComponent(u41))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(t52)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(u51))))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(t61)
                                    .addGap(111, 111, 111)
                                    .addComponent(t62)
                                    .addGap(110, 110, 110)
                                    .addComponent(u61)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(348, 348, 348)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(u82)
                                    .addComponent(u72))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton2)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel14)
                        .addGap(36, 36, 36)
                        .addComponent(Stanza1)
                        .addGap(34, 34, 34)
                        .addComponent(Stanza2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Stanza3)
                            .addComponent(t31)
                            .addComponent(t32)
                            .addComponent(u31)
                            .addComponent(u32)
                            .addComponent(p31)
                            .addComponent(p32))
                        .addGap(27, 27, 27))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13))
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t11)
                            .addComponent(t12)
                            .addComponent(u11)
                            .addComponent(u12)
                            .addComponent(p12)
                            .addComponent(p11))
                        .addGap(41, 41, 41)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(t21)
                            .addComponent(t22)
                            .addComponent(u21)
                            .addComponent(p22)
                            .addComponent(p21)
                            .addComponent(u22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Stanza4)
                    .addComponent(t41)
                    .addComponent(t42)
                    .addComponent(u41)
                    .addComponent(u42)
                    .addComponent(p41)
                    .addComponent(p42))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Stanza5)
                    .addComponent(t51)
                    .addComponent(t52)
                    .addComponent(u51)
                    .addComponent(u52)
                    .addComponent(p51)
                    .addComponent(p52))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Bagno)
                    .addComponent(t61)
                    .addComponent(t62)
                    .addComponent(u61)
                    .addComponent(u62)
                    .addComponent(p61)
                    .addComponent(p62))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SalaDiAttesa)
                    .addComponent(t71)
                    .addComponent(t72)
                    .addComponent(u71)
                    .addComponent(u72)
                    .addComponent(p71)
                    .addComponent(p72))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Corridoio)
                    .addComponent(t81)
                    .addComponent(t82)
                    .addComponent(u81)
                    .addComponent(u82)
                    .addComponent(p81)
                    .addComponent(p82))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        String sql5= "select * from ospedale.dato where IDsensore=1 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql6= "select * from ospedale.dato where IDsensore=2 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql7= "select * from ospedale.dato where IDsensore=3 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql8= "select * from ospedale.dato where IDsensore=4 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql9= "select * from ospedale.dato where IDsensore=5 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql10= "select * from ospedale.dato where IDsensore=6 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql11= "select * from ospedale.dato where IDsensore=7 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql12= "select * from ospedale.dato where IDsensore=8 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql13= "select * from ospedale.dato where IDsensore=9 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql14= "select * from ospedale.dato where IDsensore=10 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql15= "select * from ospedale.dato where IDsensore=11 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql16= "select * from ospedale.dato where IDsensore=12 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql17= "select * from ospedale.dato where IDsensore=13 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql18= "select * from ospedale.dato where IDsensore=14 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql19= "select * from ospedale.dato where IDsensore=15 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql20= "select * from ospedale.dato where IDsensore=16 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql21= "select * from ospedale.dato where IDsensore=17 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql22= "select * from ospedale.dato where IDsensore=18 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql23= "select * from ospedale.dato where IDsensore=19 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql24= "select * from ospedale.dato where IDsensore=20 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql25= "select * from ospedale.dato where IDsensore=21 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql26= "select * from ospedale.dato where IDsensore=22 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql27= "select * from ospedale.dato where IDsensore=23 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql28= "select * from ospedale.dato where IDsensore=24 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql29= "select * from ospedale.dato where IDsensore=25 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql30= "select * from ospedale.dato where IDsensore=26 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql31= "select * from ospedale.dato where IDsensore=27 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql32= "select * from ospedale.dato where IDsensore=28 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql33= "select * from ospedale.dato where IDsensore=29 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql34= "select * from ospedale.dato where IDsensore=30 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql35= "select * from ospedale.dato where IDsensore=31 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql36= "select * from ospedale.dato where IDsensore=32 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql37= "select * from ospedale.dato where IDsensore=33 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql38= "select * from ospedale.dato where IDsensore=34 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql39= "select * from ospedale.dato where IDsensore=35 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql40= "select * from ospedale.dato where IDsensore=36 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql41= "select * from ospedale.dato where IDsensore=37 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql42= "select * from ospedale.dato where IDsensore=38 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql43= "select * from ospedale.dato where IDsensore=39 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql44= "select * from ospedale.dato where IDsensore=40 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql45= "select * from ospedale.dato where IDsensore=41 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql46= "select * from ospedale.dato where IDsensore=42 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql47= "select * from ospedale.dato where IDsensore=43 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql48= "select * from ospedale.dato where IDsensore=44 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql49= "select * from ospedale.dato where IDsensore=45 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql50= "select * from ospedale.dato where IDsensore=46 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql51= "select * from ospedale.dato where IDsensore=47 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        String sql52= "select * from ospedale.dato where IDsensore=48 AND data_rilevamento > subdate(current_timestamp(), INTERVAL 60 SECOND) order by ID desc limit 1";
        
       try {
           con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/ospedale","root","ciao123abcd");
       } catch (SQLException ex) {
           Logger.getLogger(Zona1.class.getName()).log(Level.SEVERE, null, ex);
       }
        try{
            pst5= con1.prepareStatement(sql5);
            pst6= con1.prepareStatement(sql6);
            pst7= con1.prepareStatement(sql7);
            pst8= con1.prepareStatement(sql8);
            pst9= con1.prepareStatement(sql9);
            pst10= con1.prepareStatement(sql10);
            pst11= con1.prepareStatement(sql11);
            pst12= con1.prepareStatement(sql12);
            pst13= con1.prepareStatement(sql13);
            pst14= con1.prepareStatement(sql14);
            pst15= con1.prepareStatement(sql15);
            pst16= con1.prepareStatement(sql16);
            pst17= con1.prepareStatement(sql17);
            pst18= con1.prepareStatement(sql18);
            pst19= con1.prepareStatement(sql19);
            pst20= con1.prepareStatement(sql20);
            pst21= con1.prepareStatement(sql21);
            pst22= con1.prepareStatement(sql22);
            pst23= con1.prepareStatement(sql23);
            pst24= con1.prepareStatement(sql24);
            pst25= con1.prepareStatement(sql25);
            pst26= con1.prepareStatement(sql26);
            pst27= con1.prepareStatement(sql27);
            pst28= con1.prepareStatement(sql28);
            pst29= con1.prepareStatement(sql29);
            pst30= con1.prepareStatement(sql30);
            pst31= con1.prepareStatement(sql31);
            pst32= con1.prepareStatement(sql32);
            pst33= con1.prepareStatement(sql33);
            pst34= con1.prepareStatement(sql34);
            pst35= con1.prepareStatement(sql35);
            pst36= con1.prepareStatement(sql36);
            pst37= con1.prepareStatement(sql37);
            pst38= con1.prepareStatement(sql38);
            pst39= con1.prepareStatement(sql39);
            pst40= con1.prepareStatement(sql40);
            pst41= con1.prepareStatement(sql41);
            pst42= con1.prepareStatement(sql42);
            pst43= con1.prepareStatement(sql43);
            pst44= con1.prepareStatement(sql44);
            pst45= con1.prepareStatement(sql45);
            pst46= con1.prepareStatement(sql46);
            pst47= con1.prepareStatement(sql47);
            pst48= con1.prepareStatement(sql48);
            pst49= con1.prepareStatement(sql49);
            pst50= con1.prepareStatement(sql50);
            pst51= con1.prepareStatement(sql51);
            pst52= con1.prepareStatement(sql52);
            pst5.execute();
            pst6.execute();
            pst7.execute();
            pst8.execute();
            pst9.execute();
            pst10.execute();
            pst11.execute();
            pst12.execute();
            pst13.execute();
            pst14.execute();
            pst15.execute();
            pst16.execute();
            pst17.execute();
            pst18.execute();
            pst19.execute();
            pst20.execute();
            pst21.execute();
            pst22.execute();
            pst23.execute();
            pst24.execute();
            pst25.execute();
            pst26.execute();
            pst27.execute();
            pst28.execute();
            pst29.execute();
            pst30.execute();
            pst31.execute();
            pst32.execute();
            pst33.execute();
            pst34.execute();
            pst35.execute();
            pst36.execute();
            pst37.execute();
            pst38.execute();
            pst39.execute();
            pst40.execute();
            pst41.execute();
            pst42.execute();
            pst43.execute();
            pst44.execute();
            pst45.execute();
            pst46.execute();
            pst47.execute();
            pst48.execute();
            pst49.execute();
            pst50.execute();
            pst51.execute();
            pst52.execute();
            rs5=pst5.getResultSet();
            rs6=pst6.getResultSet();
            rs7=pst7.getResultSet();
            rs8=pst8.getResultSet();
            rs9=pst9.getResultSet();
            rs10=pst10.getResultSet();
            rs11=pst11.getResultSet();
            rs12=pst12.getResultSet();
            rs13=pst13.getResultSet();
            rs14=pst14.getResultSet();
            rs15=pst15.getResultSet();
            rs16=pst16.getResultSet();
            rs17=pst17.getResultSet();
            rs18=pst18.getResultSet();
            rs19=pst19.getResultSet();
            rs20=pst20.getResultSet();
            rs21=pst21.getResultSet();
            rs22=pst22.getResultSet();
            rs23=pst23.getResultSet();
            rs24=pst24.getResultSet();
            rs25=pst25.getResultSet();
            rs26=pst26.getResultSet();
            rs27=pst27.getResultSet();
            rs28=pst28.getResultSet();
            rs29=pst29.getResultSet();
            rs30=pst30.getResultSet();
            rs31=pst31.getResultSet();
            rs32=pst32.getResultSet();
            rs33=pst33.getResultSet();
            rs34=pst34.getResultSet();
            rs35=pst35.getResultSet();
            rs36=pst36.getResultSet();
            rs37=pst37.getResultSet();
            rs38=pst38.getResultSet();
            rs39=pst39.getResultSet();
            rs40=pst40.getResultSet();
            rs41=pst41.getResultSet();
            rs42=pst42.getResultSet();
            rs43=pst43.getResultSet();
            rs44=pst44.getResultSet();
            rs45=pst45.getResultSet();
            rs46=pst46.getResultSet();
            rs47=pst47.getResultSet();
            rs48=pst48.getResultSet();
            rs49=pst49.getResultSet();
            rs50=pst50.getResultSet();
            rs51=pst51.getResultSet();
            rs52=pst52.getResultSet();
            if(rs5.next() ) 
            {
               t11.setText(String.valueOf(rs5.getInt("valore")) + "°");
        }      
            else t11.setText("null"); 
            if(rs6.next() ) 
            {
               t12.setText(String.valueOf(rs6.getInt("valore")) + "°");
        }   
            else t12.setText("null");
            if(rs7.next() ) 
            {
               u11.setText(String.valueOf(rs7.getInt("valore")) + "%");
        }   
            else u11.setText("null");
            if(rs8.next() ) 
            {
               u12.setText(String.valueOf(rs8.getInt("valore")) + "%");
        }      
            else u12.setText("null");
            if(rs9.next() ) 
            {
               p11.setText(String.valueOf(rs9.getInt("valore")) + "%");
        }      
            else p11.setText("null");
            if(rs10.next() ) 
            {
               p12.setText(String.valueOf(rs10.getInt("valore")) + "%");
        }      
            else p12.setText("null");
            if(rs11.next() ) 
            {
               t21.setText(String.valueOf(rs11.getInt("valore")) + "°");
        }      
            else t21.setText("null"); 
            if(rs12.next() ) 
            {
               t22.setText(String.valueOf(rs12.getInt("valore")) + "°");
        }   
            else t22.setText("null");
            if(rs13.next() ) 
            {
               u21.setText(String.valueOf(rs13.getInt("valore")) + "%");
        }   
            else u21.setText("null");
            if(rs14.next() ) 
            {
               u22.setText(String.valueOf(rs14.getInt("valore")) + "%");
        }      
            else u22.setText("null");
            if(rs15.next() ) 
            {
               p21.setText(String.valueOf(rs15.getInt("valore")) + "%");
        }      
            else p21.setText("null");
            if(rs16.next() ) 
            {
               p22.setText(String.valueOf(rs16.getInt("valore")) + "%");
        }      
            else p22.setText("null");
            if(rs17.next() ) 
            {
               t31.setText(String.valueOf(rs17.getInt("valore")) + "°");
        }      
            else t31.setText("null"); 
            if(rs18.next() ) 
            {
               t32.setText(String.valueOf(rs18.getInt("valore")) + "°");
        }   
            else t32.setText("null");
            if(rs19.next() ) 
            {
               u31.setText(String.valueOf(rs19.getInt("valore")) + "%");
        }   
            else u31.setText("null");
            if(rs20.next() ) 
            {
               u32.setText(String.valueOf(rs20.getInt("valore")) + "%");
        }      
            else u32.setText("null");
            if(rs21.next() ) 
            {
               p31.setText(String.valueOf(rs21.getInt("valore")) + "%");
        }      
            else p31.setText("null");
            if(rs22.next() ) 
            {
               p32.setText(String.valueOf(rs22.getInt("valore")) + "%");
        }      
            else p32.setText("null");
        if(rs23.next() ) 
            {
               t41.setText(String.valueOf(rs23.getInt("valore")) + "°");
        }      
            else t41.setText("null"); 
            if(rs24.next() ) 
            {
               t42.setText(String.valueOf(rs24.getInt("valore")) + "°");
        }   
            else t42.setText("null");
            if(rs25.next() ) 
            {
               u41.setText(String.valueOf(rs25.getInt("valore")) + "%");
        }   
            else u41.setText("null");
            if(rs26.next() ) 
            {
               u42.setText(String.valueOf(rs26.getInt("valore")) + "%");
        }      
            else u42.setText("null");
            if(rs27.next() ) 
            {
               p41.setText(String.valueOf(rs27.getInt("valore")) + "%");
        }      
            else p41.setText("null");
            if(rs28.next() ) 
            {
               p42.setText(String.valueOf(rs28.getInt("valore")) + "%");
        }      
            else p42.setText("null");
            if(rs29.next() ) 
            {
               t51.setText(String.valueOf(rs29.getInt("valore")) + "°");
        }      
            else t51.setText("null"); 
            if(rs30.next() ) 
            {
               t52.setText(String.valueOf(rs30.getInt("valore")) + "°");
        }   
            else t52.setText("null");
            if(rs31.next() ) 
            {
               u51.setText(String.valueOf(rs31.getInt("valore")) + "%");
        }   
            else u51.setText("null");
            if(rs32.next() ) 
            {
               u52.setText(String.valueOf(rs32.getInt("valore")) + "%");
        }      
            else u52.setText("null");
            if(rs33.next() ) 
            {
               p51.setText(String.valueOf(rs33.getInt("valore")) + "%");
        }      
            else p51.setText("null");
            if(rs34.next() ) 
            {
               p52.setText(String.valueOf(rs34.getInt("valore")) + "%");
        }      
            else p52.setText("null");
            if(rs35.next() ) 
            {
               t61.setText(String.valueOf(rs35.getInt("valore")) + "°");
        }      
            else t61.setText("null"); 
            if(rs36.next() ) 
            {
               t62.setText(String.valueOf(rs36.getInt("valore")) + "°");
        }   
            else t62.setText("null");
            if(rs37.next() ) 
            {
               u61.setText(String.valueOf(rs37.getInt("valore")) + "%");
        }   
            else u61.setText("null");
            if(rs38.next() ) 
            {
               u62.setText(String.valueOf(rs38.getInt("valore")) + "%");
        }      
            else u62.setText("null");
            if(rs39.next() ) 
            {
               p61.setText(String.valueOf(rs39.getInt("valore")) + "%");
        }      
            else p61.setText("null");
            if(rs40.next() ) 
            {
               p62.setText(String.valueOf(rs40.getInt("valore")) + "%");
        }      
            else p62.setText("null");
            if(rs41.next() ) 
            {
               t71.setText(String.valueOf(rs41.getInt("valore")) + "°");
        }      
            else t71.setText("null"); 
            if(rs42.next() ) 
            {
               t72.setText(String.valueOf(rs42.getInt("valore")) + "°");
        }   
            else t72.setText("null");
            if(rs43.next() ) 
            {
               u71.setText(String.valueOf(rs43.getInt("valore")) + "%");
        }   
            else u71.setText("null");
            if(rs44.next() ) 
            {
               u72.setText(String.valueOf(rs44.getInt("valore")) + "%");
        }      
            else u72.setText("null");
            if(rs45.next() ) 
            {
               p71.setText(String.valueOf(rs45.getInt("valore")) + "%");
        }      
            else p71.setText("null");
            if(rs46.next() ) 
            {
               p72.setText(String.valueOf(rs46.getInt("valore")) + "%");
        }      
            else p72.setText("null");
            if(rs47.next() ) 
            {
               t81.setText(String.valueOf(rs47.getInt("valore")) + "°");
        }      
            else t81.setText("null"); 
            if(rs48.next() ) 
            {
               t82.setText(String.valueOf(rs48.getInt("valore")) + "°");
        }   
            else t82.setText("null");
            if(rs49.next() ) 
            {
               u81.setText(String.valueOf(rs49.getInt("valore")) + "%");
        }   
            else u81.setText("null");
            if(rs50.next() ) 
            {
               u82.setText(String.valueOf(rs50.getInt("valore")) + "%");
        }      
            else u82.setText("null");
            if(rs51.next() ) 
            {
               p81.setText(String.valueOf(rs51.getInt("valore")) + "%");
        }      
            else p81.setText("null");
            if(rs52.next() ) 
            {
               p82.setText(String.valueOf(rs52.getInt("valore")) + "%");
        }      
            else p82.setText("null");
            //Controllo Stanze
            //STANZA1
            if((t11.getText().equals("null")|t12.getText().equals("null")|u11.getText().equals("null")|u12.getText().equals("null")|p11.getText().equals("null")|p12.getText().equals("null")) |
                    (((rs5.getInt("valore")<20)|(rs5.getInt("valore")>25)|(rs6.getInt("valore")<20)|(rs6.getInt("valore")>25)) &&
                     ((rs7.getInt("valore")<40)|(rs7.getInt("valore")>60)|(rs8.getInt("valore")<40)|(rs8.getInt("valore")>60)) &&
                     ((rs9.getInt("valore")<15)|(rs9.getInt("valore")>21)|(rs10.getInt("valore")<15)|(rs10.getInt("valore")>21))
                    )
              )
                Stanza1.setForeground(Color.orange);
            
            else if((t11.getText().equals("null")&&t12.getText().equals("null")|u11.getText().equals("null")&&u12.getText().equals("null")|p11.getText().equals("null")&&p12.getText().equals("null")) |
                    (((rs5.getInt("valore")<20)|(rs5.getInt("valore")>25)&&(rs6.getInt("valore")<20)|(rs6.getInt("valore")>25)) |
                     ((rs7.getInt("valore")<40)|(rs7.getInt("valore")>60)&&(rs8.getInt("valore")<40)|(rs8.getInt("valore")>60)) |
                     ((rs9.getInt("valore")<15)|(rs9.getInt("valore")>21)&&(rs10.getInt("valore")<15)|(rs10.getInt("valore")>21))
                    )
                   )
                Stanza1.setForeground(Color.red);
                  else Stanza1.setForeground(Color.green);
            //STANZA2
            if((t21.getText().equals("null")|t22.getText().equals("null")|u21.getText().equals("null")|u22.getText().equals("null")|p21.getText().equals("null")|p22.getText().equals("null")) |
                    (((rs11.getInt("valore")<20)|(rs11.getInt("valore")>25)|(rs12.getInt("valore")<20)|(rs12.getInt("valore")>25)) &&
                     ((rs13.getInt("valore")<40)|(rs13.getInt("valore")>60)|(rs14.getInt("valore")<40)|(rs14.getInt("valore")>60)) &&
                     ((rs15.getInt("valore")<15)|(rs15.getInt("valore")>21)|(rs16.getInt("valore")<15)|(rs16.getInt("valore")>21))
                    )
              )
                Stanza2.setForeground(Color.orange);
            
            else if((t21.getText().equals("null")&&t22.getText().equals("null")|u21.getText().equals("null")&&u22.getText().equals("null")|p21.getText().equals("null")&&p22.getText().equals("null")) |
                    (((rs11.getInt("valore")<20)|(rs11.getInt("valore")>25)&&(rs12.getInt("valore")<20)|(rs12.getInt("valore")>25)) |
                     ((rs13.getInt("valore")<40)|(rs13.getInt("valore")>60)&&(rs14.getInt("valore")<40)|(rs14.getInt("valore")>60)) |
                     ((rs15.getInt("valore")<15)|(rs15.getInt("valore")>21)&&(rs16.getInt("valore")<15)|(rs16.getInt("valore")>21))
                    )
                   )
                Stanza2.setForeground(Color.red);
                 else Stanza2.setForeground(Color.green);
            //STANZA3
            if((t31.getText().equals("null")|t32.getText().equals("null")|u31.getText().equals("null")|u32.getText().equals("null")|p31.getText().equals("null")|p32.getText().equals("null")) |
                    (((rs17.getInt("valore")<20)|(rs17.getInt("valore")>25)|(rs18.getInt("valore")<20)|(rs18.getInt("valore")>25)) &&
                     ((rs19.getInt("valore")<40)|(rs19.getInt("valore")>60)|(rs20.getInt("valore")<40)|(rs20.getInt("valore")>60)) &&
                     ((rs21.getInt("valore")<15)|(rs21.getInt("valore")>21)|(rs22.getInt("valore")<15)|(rs22.getInt("valore")>21))
                    )
              )
                Stanza3.setForeground(Color.orange);
            
            else if((t31.getText().equals("null")&&t32.getText().equals("null")|u31.getText().equals("null")&&u32.getText().equals("null")|p31.getText().equals("null")&&p32.getText().equals("null")) |
                    (((rs17.getInt("valore")<20)|(rs17.getInt("valore")>25)&&(rs18.getInt("valore")<20)|(rs18.getInt("valore")>25)) |
                     ((rs19.getInt("valore")<40)|(rs19.getInt("valore")>60)&&(rs20.getInt("valore")<40)|(rs20.getInt("valore")>60)) |
                     ((rs21.getInt("valore")<15)|(rs21.getInt("valore")>21)&&(rs22.getInt("valore")<15)|(rs22.getInt("valore")>21))
                    )
                   )
                Stanza3.setForeground(Color.red);
                 else Stanza3.setForeground(Color.green);
            //STANZA4
            if((t41.getText().equals("null")|t42.getText().equals("null")|u41.getText().equals("null")|u42.getText().equals("null")|p41.getText().equals("null")|p42.getText().equals("null")) |
                    (((rs23.getInt("valore")<20)|(rs23.getInt("valore")>25)|(rs24.getInt("valore")<20)|(rs24.getInt("valore")>25)) &&
                     ((rs25.getInt("valore")<40)|(rs25.getInt("valore")>60)|(rs26.getInt("valore")<40)|(rs26.getInt("valore")>60)) &&
                     ((rs27.getInt("valore")<15)|(rs27.getInt("valore")>21)|(rs28.getInt("valore")<15)|(rs28.getInt("valore")>21))
                    )
              )
                Stanza4.setForeground(Color.orange);
            
            else if((t41.getText().equals("null")&&t42.getText().equals("null")|u41.getText().equals("null")&&u42.getText().equals("null")|p41.getText().equals("null")&&p42.getText().equals("null")) |
                    (((rs23.getInt("valore")<20)|(rs23.getInt("valore")>25)&&(rs24.getInt("valore")<20)|(rs24.getInt("valore")>25)) |
                     ((rs25.getInt("valore")<40)|(rs25.getInt("valore")>60)&&(rs25.getInt("valore")<40)|(rs25.getInt("valore")>60)) |
                     ((rs27.getInt("valore")<15)|(rs27.getInt("valore")>21)&&(rs28.getInt("valore")<15)|(rs28.getInt("valore")>21))
                    )
                   )
                Stanza4.setForeground(Color.red);
                 else Stanza4.setForeground(Color.green);
            //STANZA5
            if((t51.getText().equals("null")|t52.getText().equals("null")|u51.getText().equals("null")|u52.getText().equals("null")|p51.getText().equals("null")|p52.getText().equals("null")) |
                    (((rs29.getInt("valore")<20)|(rs29.getInt("valore")>25)|(rs30.getInt("valore")<20)|(rs30.getInt("valore")>25)) &&
                     ((rs31.getInt("valore")<40)|(rs31.getInt("valore")>60)|(rs32.getInt("valore")<40)|(rs32.getInt("valore")>60)) &&
                     ((rs33.getInt("valore")<15)|(rs33.getInt("valore")>21)|(rs34.getInt("valore")<15)|(rs34.getInt("valore")>21))
                    )
              )
                Stanza5.setForeground(Color.orange);
            
            else if((t51.getText().equals("null")&&t52.getText().equals("null")|u51.getText().equals("null")&&u52.getText().equals("null")|p51.getText().equals("null")&&p52.getText().equals("null")) |
                    (((rs29.getInt("valore")<20)|(rs29.getInt("valore")>25)&&(rs30.getInt("valore")<20)|(rs30.getInt("valore")>25)) |
                     ((rs31.getInt("valore")<40)|(rs31.getInt("valore")>60)&&(rs32.getInt("valore")<40)|(rs32.getInt("valore")>60)) |
                     ((rs33.getInt("valore")<15)|(rs33.getInt("valore")>21)&&(rs34.getInt("valore")<15)|(rs34.getInt("valore")>21))
                    )
                   )
                Stanza5.setForeground(Color.red);
                 else Stanza5.setForeground(Color.green);
            //STANZA6
            if((t61.getText().equals("null")|t62.getText().equals("null")|u61.getText().equals("null")|u62.getText().equals("null")|p61.getText().equals("null")|p62.getText().equals("null")) |
                    (((rs35.getInt("valore")<20)|(rs35.getInt("valore")>25)|(rs36.getInt("valore")<20)|(rs36.getInt("valore")>25)) &&
                     ((rs37.getInt("valore")<40)|(rs37.getInt("valore")>60)|(rs38.getInt("valore")<40)|(rs38.getInt("valore")>60)) &&
                     ((rs39.getInt("valore")<15)|(rs39.getInt("valore")>21)|(rs40.getInt("valore")<15)|(rs40.getInt("valore")>21))
                    )
              )
                Bagno.setForeground(Color.orange);
            
            else if((t61.getText().equals("null")&&t62.getText().equals("null")|u61.getText().equals("null")&&u62.getText().equals("null")|p61.getText().equals("null")&&p62.getText().equals("null")) |
                    (((rs35.getInt("valore")<20)|(rs35.getInt("valore")>25)&&(rs36.getInt("valore")<20)|(rs36.getInt("valore")>25)) |
                     ((rs37.getInt("valore")<40)|(rs37.getInt("valore")>60)&&(rs38.getInt("valore")<40)|(rs38.getInt("valore")>60)) |
                     ((rs39.getInt("valore")<15)|(rs39.getInt("valore")>21)&&(rs40.getInt("valore")<15)|(rs40.getInt("valore")>21))
                    )
                   )
                Bagno.setForeground(Color.red);
                 else Bagno.setForeground(Color.green);
            //STANZA7
            if((t71.getText().equals("null")|t72.getText().equals("null")|u71.getText().equals("null")|u72.getText().equals("null")|p71.getText().equals("null")|p72.getText().equals("null")) |
                    (((rs41.getInt("valore")<20)|(rs41.getInt("valore")>25)|(rs42.getInt("valore")<20)|(rs42.getInt("valore")>25)) &&
                     ((rs43.getInt("valore")<40)|(rs43.getInt("valore")>60)|(rs44.getInt("valore")<40)|(rs44.getInt("valore")>60)) &&
                     ((rs45.getInt("valore")<15)|(rs45.getInt("valore")>21)|(rs46.getInt("valore")<15)|(rs46.getInt("valore")>21))
                    )
              )
                SalaDiAttesa.setForeground(Color.orange);
            
            else if((t71.getText().equals("null")&&t72.getText().equals("null")|u71.getText().equals("null")&&u72.getText().equals("null")|p71.getText().equals("null")&&p72.getText().equals("null")) |
                    (((rs41.getInt("valore")<20)|(rs41.getInt("valore")>25)&&(rs42.getInt("valore")<20)|(rs42.getInt("valore")>25)) |
                     ((rs43.getInt("valore")<40)|(rs43.getInt("valore")>60)&&(rs44.getInt("valore")<40)|(rs44.getInt("valore")>60)) |
                     ((rs45.getInt("valore")<15)|(rs45.getInt("valore")>21)&&(rs46.getInt("valore")<15)|(rs46.getInt("valore")>21))
                    )
                   )
                SalaDiAttesa.setForeground(Color.red);
                 else SalaDiAttesa.setForeground(Color.green);
            //STANZA8
            if((t81.getText().equals("null")|t82.getText().equals("null")|u81.getText().equals("null")|u82.getText().equals("null")|p81.getText().equals("null")|p82.getText().equals("null")) |
                    (((rs47.getInt("valore")<20)|(rs47.getInt("valore")>25)|(rs48.getInt("valore")<20)|(rs48.getInt("valore")>25)) &&
                     ((rs49.getInt("valore")<40)|(rs49.getInt("valore")>60)|(rs50.getInt("valore")<40)|(rs50.getInt("valore")>60)) &&
                     ((rs51.getInt("valore")<15)|(rs51.getInt("valore")>21)|(rs52.getInt("valore")<15)|(rs52.getInt("valore")>21))
                    )
              )
                Corridoio.setForeground(Color.orange);
            
            else if((t81.getText().equals("null")&&t82.getText().equals("null")|u81.getText().equals("null")&&u82.getText().equals("null")|p81.getText().equals("null")&&p82.getText().equals("null")) |
                    (((rs47.getInt("valore")<20)|(rs47.getInt("valore")>25)&&(rs48.getInt("valore")<20)|(rs48.getInt("valore")>25)) |
                     ((rs49.getInt("valore")<40)|(rs49.getInt("valore")>60)&&(rs50.getInt("valore")<40)|(rs50.getInt("valore")>60)) |
                     ((rs51.getInt("valore")<15)|(rs51.getInt("valore")>21)&&(rs52.getInt("valore")<15)|(rs52.getInt("valore")>21))
                    )
                   )
                Corridoio.setForeground(Color.red);
                 else Corridoio.setForeground(Color.green);
            
        }catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed
    
    public static void ViewZone1() {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Zona1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Zona1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Zona1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Zona1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Zona1().setVisible(true);
            }
        });
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Zona1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Zona1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Zona1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Zona1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        Zona1 td1= new Zona1();
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Zona1().setVisible(true);
            }
        });
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==t){
            jButton1.doClick();
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Bagno;
    private javax.swing.JLabel Corridoio;
    private javax.swing.JLabel SalaDiAttesa;
    private javax.swing.JLabel Stanza1;
    private javax.swing.JLabel Stanza2;
    private javax.swing.JLabel Stanza3;
    private javax.swing.JLabel Stanza4;
    private javax.swing.JLabel Stanza5;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel p11;
    private javax.swing.JLabel p12;
    private javax.swing.JLabel p21;
    private javax.swing.JLabel p22;
    private javax.swing.JLabel p31;
    private javax.swing.JLabel p32;
    private javax.swing.JLabel p41;
    private javax.swing.JLabel p42;
    private javax.swing.JLabel p51;
    private javax.swing.JLabel p52;
    private javax.swing.JLabel p61;
    private javax.swing.JLabel p62;
    private javax.swing.JLabel p71;
    private javax.swing.JLabel p72;
    private javax.swing.JLabel p81;
    private javax.swing.JLabel p82;
    private javax.swing.JLabel t11;
    private javax.swing.JLabel t12;
    private javax.swing.JLabel t21;
    private javax.swing.JLabel t22;
    private javax.swing.JLabel t31;
    private javax.swing.JLabel t32;
    private javax.swing.JLabel t41;
    private javax.swing.JLabel t42;
    private javax.swing.JLabel t51;
    private javax.swing.JLabel t52;
    private javax.swing.JLabel t61;
    private javax.swing.JLabel t62;
    private javax.swing.JLabel t71;
    private javax.swing.JLabel t72;
    private javax.swing.JLabel t81;
    private javax.swing.JLabel t82;
    private javax.swing.JLabel u11;
    private javax.swing.JLabel u12;
    private javax.swing.JLabel u21;
    private javax.swing.JLabel u22;
    private javax.swing.JLabel u31;
    private javax.swing.JLabel u32;
    private javax.swing.JLabel u41;
    private javax.swing.JLabel u42;
    private javax.swing.JLabel u51;
    private javax.swing.JLabel u52;
    private javax.swing.JLabel u61;
    private javax.swing.JLabel u62;
    private javax.swing.JLabel u71;
    private javax.swing.JLabel u72;
    private javax.swing.JLabel u81;
    private javax.swing.JLabel u82;
    // End of variables declaration//GEN-END:variables
}
