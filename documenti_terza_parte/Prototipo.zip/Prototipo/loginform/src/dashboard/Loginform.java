/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard;

import java.io.IOException;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author eriko
 */
public class Loginform {
    static Amministrazione njf1= new Amministrazione();

    /**
     * @param args the command line arguments
     */
    
   public static void main(String[] args){
       njf1.setVisible(true);
       //Timer timer=new Timer();
       //TimerTask task= new MyTask();
       //timer.schedule(task,1000,5000);
               	 int y=0;
   	 Thread t1 = Thread.currentThread();
         njf1.setVisible(true);
   	 try {
			Socket s = new Socket("localhost", 9888);
			for (int i=0;i<6;i++) {
			for(int z=0, id=1;z<48;z++,id++) {
				//y= ((int) (Math.random()*100));
				//System.out.println(y);
		    	Sensore a= new Sensore(id,"umidita", y, 40, 60);
                        Controller c= new Controller(a);
                        y=c.controllo();
                        a.cambio_valore(y);
                        
		    	a.invio();
			}
			s.close();
			try {
				t1.sleep(55000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}} catch (IOException e) {
			    // TODO Auto-generated catch block
			    e.printStackTrace();
		        }
    
}
    
}
